
import React from 'react';
import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import AuroraEffect from '@/components/ui/aurora-effect';

const WelcomeSection: React.FC = () => {
  return (
    <section className="relative overflow-hidden pt-32 md:pt-40 pb-16 md:pb-20">
      {/* Aurora background */}
      <AuroraEffect intensity="high" />
      
      {/* Content */}
      <div className="container max-w-5xl px-6 mx-auto text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-800 mb-4 md:mb-6 animate-fade-in">
          Welcome to Your Trading Journal
        </h1>
        <p className="text-lg md:text-xl text-neutral-600 max-w-2xl mx-auto mb-8 md:mb-12 animate-fade-in [animation-delay:200ms]">
          Track your trades, analyze your performance, and improve your trading strategy with precision and clarity.
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 animate-fade-in [animation-delay:400ms]">
          <Link to="/trades">
            <Button size="lg" className="px-6 py-6 text-md rounded-full shadow-button">
              Start Tracking Trades
              <ChevronRight className="ml-1 w-4 h-4" />
            </Button>
          </Link>
          <Link to="/analysis">
            <Button variant="outline" size="lg" className="px-6 py-6 text-md rounded-full shadow-button">
              View Performance
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default WelcomeSection;
