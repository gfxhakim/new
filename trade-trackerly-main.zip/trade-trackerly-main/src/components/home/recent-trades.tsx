
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';
import TradeCard, { TradeData } from '@/components/ui/trade-card';

// Mock data - would be replaced with real data in a production app
const recentTradesData: TradeData[] = [
  {
    id: '1',
    asset: 'Apple Inc.',
    date: '2023-09-15T10:30:00',
    entryPrice: 170.50,
    exitPrice: 175.25,
    quantity: 10,
    direction: 'Buy',
    profitLoss: 47.50,
    notes: 'Entered after positive earnings report, exited at resistance level.',
  },
  {
    id: '2',
    asset: 'Bitcoin',
    date: '2023-09-10T14:45:00',
    entryPrice: 26800.00,
    exitPrice: 27500.00,
    quantity: 0.5,
    direction: 'Buy',
    profitLoss: 350.00,
  },
  {
    id: '3',
    asset: 'Tesla Inc.',
    date: '2023-09-05T09:15:00',
    entryPrice: 245.75,
    exitPrice: 238.50,
    quantity: 8,
    direction: 'Sell',
    profitLoss: -58.00,
    commission: 9.99,
    notes: 'Shorted at resistance, covered too early.',
  },
  {
    id: '4',
    asset: 'EUR/USD',
    date: '2023-09-01T11:20:00',
    entryPrice: 1.0825,
    exitPrice: 1.0875,
    quantity: 10000,
    direction: 'Buy',
    profitLoss: 500.00,
  },
  {
    id: '5',
    asset: 'Amazon.com Inc.',
    date: '2023-08-28T15:30:00',
    entryPrice: 138.50,
    exitPrice: 135.75,
    quantity: 12,
    direction: 'Buy',
    profitLoss: -33.00,
    notes: 'Entered too early, market reversed after Fed announcement.',
  }
];

const RecentTrades: React.FC = () => {
  return (
    <section className="py-16 px-6 bg-neutral-50">
      <div className="container max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-neutral-800">Recent Trades</h2>
          <Link to="/trades">
            <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-600">
              View All Trades
              <ChevronRight className="ml-1 w-4 h-4" />
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {recentTradesData.map((trade, index) => (
            <TradeCard 
              key={trade.id} 
              trade={trade} 
              className={`animate-slide-in [animation-delay:${index * 100}ms]`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default RecentTrades;
