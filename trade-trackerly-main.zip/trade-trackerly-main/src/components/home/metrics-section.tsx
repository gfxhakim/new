
import React from 'react';
import MetricsCard from '@/components/ui/metrics-card';
import { TrendingUp, BarChart2, DollarSign, PieChart, Calendar } from 'lucide-react';

// Mock data - would be replaced with real data in a production app
const metricsData = {
  totalProfitLoss: 12580.45,
  totalProfitLossData: [5, 8, 12, 10, 15, 18, 20, 18, 22, 28, 30],
  
  winRate: 68,
  winRateData: [60, 62, 65, 63, 64, 67, 65, 68, 67, 68],
  
  averageWin: 450.75,
  averageWinData: [380, 390, 410, 430, 450, 445, 470, 455, 450],
  
  averageLoss: -215.30,
  averageLossData: [-190, -200, -210, -205, -215, -220, -210, -215],
  
  totalTrades: 124,
  totalTradesData: [10, 22, 35, 48, 62, 78, 90, 105, 115, 124],
};

const MetricsSection: React.FC = () => {
  return (
    <section className="py-16 px-6">
      <div className="container max-w-6xl mx-auto">
        <h2 className="text-2xl font-bold text-neutral-800 mb-6">Your Trading Metrics</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <MetricsCard
            title="Total Profit/Loss"
            value={metricsData.totalProfitLoss}
            sparklineData={metricsData.totalProfitLossData}
            icon={DollarSign}
            trend="up"
            trendValue="8.5%"
            isMonetary={true}
            className="animate-scale-in"
          />
          
          <MetricsCard
            title="Win Rate"
            value={metricsData.winRate}
            sparklineData={metricsData.winRateData}
            icon={TrendingUp}
            trend="up"
            trendValue="3%"
            isPercentage={true}
            className="animate-scale-in [animation-delay:100ms]"
          />
          
          <MetricsCard
            title="Average Win"
            value={metricsData.averageWin}
            sparklineData={metricsData.averageWinData}
            icon={BarChart2}
            trend="up"
            trendValue="5.2%"
            isMonetary={true}
            className="animate-scale-in [animation-delay:200ms]"
          />
          
          <MetricsCard
            title="Average Loss"
            value={metricsData.averageLoss}
            sparklineData={metricsData.averageLossData}
            icon={BarChart2}
            trend="down"
            trendValue="2.8%"
            isMonetary={true}
            className="animate-scale-in [animation-delay:300ms]"
          />
          
          <MetricsCard
            title="Number of Trades"
            value={metricsData.totalTrades}
            sparklineData={metricsData.totalTradesData}
            icon={Calendar}
            className="animate-scale-in [animation-delay:400ms]"
          />
          
          <MetricsCard
            title="Risk Reward Ratio"
            value={2.1}
            icon={PieChart}
            trend="up"
            trendValue="0.2"
            className="animate-scale-in [animation-delay:500ms]"
          />
        </div>
      </div>
    </section>
  );
};

export default MetricsSection;
