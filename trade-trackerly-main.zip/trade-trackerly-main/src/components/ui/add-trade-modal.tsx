
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { CalendarIcon, X } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { TradeData } from './trade-card';
import { toast } from 'sonner';

interface AddTradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTrade: (trade: Omit<TradeData, 'id'>) => void;
}

const AddTradeModal: React.FC<AddTradeModalProps> = ({ isOpen, onClose, onAddTrade }) => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [asset, setAsset] = useState<string>('');
  const [entryPrice, setEntryPrice] = useState<string>('');
  const [exitPrice, setExitPrice] = useState<string>('');
  const [quantity, setQuantity] = useState<string>('');
  const [direction, setDirection] = useState<'Buy' | 'Sell'>('Buy');
  const [commission, setCommission] = useState<string>('0');
  const [notes, setNotes] = useState<string>('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const resetForm = () => {
    setDate(new Date());
    setAsset('');
    setEntryPrice('');
    setExitPrice('');
    setQuantity('');
    setDirection('Buy');
    setCommission('0');
    setNotes('');
    setErrors({});
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!asset.trim()) newErrors.asset = 'Asset is required';
    if (!date) newErrors.date = 'Date is required';
    if (!entryPrice) newErrors.entryPrice = 'Entry price is required';
    else if (isNaN(Number(entryPrice)) || Number(entryPrice) <= 0) 
      newErrors.entryPrice = 'Entry price must be a positive number';
    
    if (!exitPrice) newErrors.exitPrice = 'Exit price is required';
    else if (isNaN(Number(exitPrice)) || Number(exitPrice) <= 0) 
      newErrors.exitPrice = 'Exit price must be a positive number';
    
    if (!quantity) newErrors.quantity = 'Quantity is required';
    else if (isNaN(Number(quantity)) || Number(quantity) <= 0) 
      newErrors.quantity = 'Quantity must be a positive number';
    
    if (commission && (isNaN(Number(commission)) || Number(commission) < 0))
      newErrors.commission = 'Commission must be a non-negative number';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      const entryPriceNum = parseFloat(entryPrice);
      const exitPriceNum = parseFloat(exitPrice);
      const quantityNum = parseFloat(quantity);
      const commissionNum = parseFloat(commission || '0');
      
      // Calculate profit/loss
      const profitLoss = 
        direction === 'Buy'
          ? (exitPriceNum - entryPriceNum) * quantityNum - commissionNum
          : (entryPriceNum - exitPriceNum) * quantityNum - commissionNum;
      
      const newTrade: Omit<TradeData, 'id'> = {
        asset,
        date: date ? date.toISOString() : new Date().toISOString(),
        entryPrice: entryPriceNum,
        exitPrice: exitPriceNum,
        quantity: quantityNum,
        direction,
        profitLoss,
        commission: commissionNum,
        notes: notes.trim() || undefined,
      };
      
      onAddTrade(newTrade);
      toast.success('Trade added successfully');
      handleClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[425px] p-0 overflow-hidden">
        <DialogHeader className="px-6 pt-6 pb-0">
          <DialogTitle className="text-xl font-semibold">Add New Trade</DialogTitle>
          <button 
            className="absolute top-4 right-4 p-1 rounded-full text-neutral-400 hover:text-neutral-700 transition-colors"
            onClick={handleClose}
          >
            <X size={18} />
          </button>
        </DialogHeader>
        
        <div className="px-6 py-4 overflow-y-auto max-h-[70vh] space-y-5">
          <div className="space-y-2">
            <Label htmlFor="asset">Asset Name</Label>
            <Input
              id="asset"
              value={asset}
              onChange={(e) => setAsset(e.target.value)}
              placeholder="e.g. AAPL, BTC, EUR/USD"
              className={errors.asset ? "border-error" : ""}
            />
            {errors.asset && <p className="text-xs text-error">{errors.asset}</p>}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="date">Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  id="date"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    errors.date ? "border-error" : "",
                    !date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
            {errors.date && <p className="text-xs text-error">{errors.date}</p>}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="entryPrice">Entry Price</Label>
              <Input
                id="entryPrice"
                value={entryPrice}
                onChange={(e) => setEntryPrice(e.target.value)}
                placeholder="0.00"
                className={errors.entryPrice ? "border-error" : ""}
              />
              {errors.entryPrice && <p className="text-xs text-error">{errors.entryPrice}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="exitPrice">Exit Price</Label>
              <Input
                id="exitPrice"
                value={exitPrice}
                onChange={(e) => setExitPrice(e.target.value)}
                placeholder="0.00"
                className={errors.exitPrice ? "border-error" : ""}
              />
              {errors.exitPrice && <p className="text-xs text-error">{errors.exitPrice}</p>}
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="0"
                className={errors.quantity ? "border-error" : ""}
              />
              {errors.quantity && <p className="text-xs text-error">{errors.quantity}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="commission">Commission</Label>
              <Input
                id="commission"
                value={commission}
                onChange={(e) => setCommission(e.target.value)}
                placeholder="0.00"
                className={errors.commission ? "border-error" : ""}
              />
              {errors.commission && <p className="text-xs text-error">{errors.commission}</p>}
            </div>
          </div>
          
          <div className="space-y-2">
            <Label>Direction</Label>
            <div className="flex space-x-4">
              <div className="flex items-center">
                <input
                  type="radio"
                  id="directionBuy"
                  name="direction"
                  value="Buy"
                  checked={direction === 'Buy'}
                  onChange={() => setDirection('Buy')}
                  className="mr-2 w-4 h-4 text-blue-500 focus:ring-blue-500"
                />
                <Label htmlFor="directionBuy" className="cursor-pointer">Buy</Label>
              </div>
              <div className="flex items-center">
                <input
                  type="radio"
                  id="directionSell"
                  name="direction"
                  value="Sell"
                  checked={direction === 'Sell'}
                  onChange={() => setDirection('Sell')}
                  className="mr-2 w-4 h-4 text-blue-500 focus:ring-blue-500"
                />
                <Label htmlFor="directionSell" className="cursor-pointer">Sell</Label>
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any additional details about this trade..."
              className="resize-none h-20"
            />
          </div>
        </div>
        
        <DialogFooter className="px-6 py-4 border-t">
          <Button variant="outline" onClick={handleClose} className="mr-2">
            Cancel
          </Button>
          <Button onClick={handleSubmit}>
            Save Trade
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddTradeModal;
