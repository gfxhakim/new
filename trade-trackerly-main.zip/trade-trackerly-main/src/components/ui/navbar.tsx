
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { ChevronDown, Menu, X } from 'lucide-react';

const LINKS = [
  { name: 'Home', path: '/' },
  { name: 'Trades', path: '/trades' },
  { name: 'Analysis', path: '/analysis' },
  { name: 'Profile', path: '/profile' },
];

const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 20;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out px-6 md:px-8 py-4',
        {
          'glass-effect shadow-sm': scrolled,
          'bg-transparent': !scrolled,
        }
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-md bg-blue-500 flex items-center justify-center">
            <span className="text-white font-bold">TJ</span>
          </div>
          <span className="text-neutral-800 font-semibold text-xl hidden sm:inline-block">
            TradeJournal
          </span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-1">
          {LINKS.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={cn(
                'px-4 py-2 rounded-full text-sm font-medium transition-all duration-200',
                location.pathname === link.path
                  ? 'text-blue-500 bg-blue-50'
                  : 'text-neutral-600 hover:text-blue-500 hover:bg-neutral-100'
              )}
            >
              {link.name}
            </Link>
          ))}
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button
            onClick={toggleMobileMenu}
            className="p-2 rounded-full text-neutral-600 hover:text-blue-500 hover:bg-neutral-100 transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          'fixed inset-0 bg-white z-40 pt-16 px-6 transform transition-transform duration-300 ease-in-out md:hidden',
          {
            'translate-x-0': mobileMenuOpen,
            'translate-x-full': !mobileMenuOpen,
          }
        )}
      >
        <div className="flex flex-col space-y-2 pt-4">
          {LINKS.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              onClick={() => setMobileMenuOpen(false)}
              className={cn(
                'px-4 py-3 rounded-lg text-base font-medium transition-all duration-200',
                location.pathname === link.path
                  ? 'text-blue-500 bg-blue-50'
                  : 'text-neutral-600 hover:text-blue-500 hover:bg-neutral-100'
              )}
            >
              {link.name}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
