
import React from 'react';
import { cn } from '@/lib/utils';
import Sparkline from './sparkline';
import { LucideIcon } from 'lucide-react';

interface MetricsCardProps {
  title: string;
  value: string | number;
  sparklineData?: number[];
  icon?: LucideIcon;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  isPercentage?: boolean;
  isMonetary?: boolean;
  className?: string;
}

const MetricsCard: React.FC<MetricsCardProps> = ({
  title,
  value,
  sparklineData = [],
  icon: Icon,
  trend = 'neutral',
  trendValue,
  isPercentage = false,
  isMonetary = false,
  className,
}) => {
  const formattedValue = 
    isMonetary ? 
      typeof value === 'number' ? 
        new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value) 
        : value
      : value;

  return (
    <div 
      className={cn(
        "bg-white rounded-xl p-5 shadow-card border border-neutral-200 transition-all duration-300 hover:shadow-md", 
        className
      )}
    >
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center">
          {Icon && (
            <div className="mr-3 text-blue-500">
              <Icon size={18} />
            </div>
          )}
          <h3 className="text-sm font-medium text-neutral-600">{title}</h3>
        </div>
        {trend !== 'neutral' && trendValue && (
          <span 
            className={cn(
              "text-xs font-medium px-2 py-1 rounded-full flex items-center",
              {
                "bg-success/10 text-success": trend === 'up',
                "bg-error/10 text-error": trend === 'down',
              }
            )}
          >
            {trend === 'up' ? '+' : '-'}{trendValue}
            {isPercentage && '%'}
          </span>
        )}
      </div>

      <div className="flex items-end justify-between">
        <div className="flex flex-col">
          <span className="text-2xl font-bold text-neutral-800">
            {formattedValue}
            {isPercentage && !isMonetary && '%'}
          </span>
        </div>
        
        {sparklineData.length > 0 && (
          <div className="h-12 w-24">
            <Sparkline 
              data={sparklineData} 
              color={trend === 'down' ? '#FF3B30' : '#34C759'} 
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default MetricsCard;
