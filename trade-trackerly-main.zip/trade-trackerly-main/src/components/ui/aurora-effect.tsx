
import React from 'react';
import '@/styles/aurora.css';

interface AuroraEffectProps {
  className?: string;
  intensity?: 'low' | 'medium' | 'high';
}

const AuroraEffect: React.FC<AuroraEffectProps> = ({ className, intensity = 'medium' }) => {
  const intensityClass = `aurora-intensity-${intensity}`;
  
  return (
    <div className={`absolute inset-0 overflow-hidden -z-10 ${intensityClass} ${className || ''}`}>
      <div className="aurora-blur-1"></div>
      <div className="aurora-blur-2"></div>
      <div className="aurora-blur-3"></div>
      <div className="aurora-blur-4"></div>
    </div>
  );
};

export default AuroraEffect;
