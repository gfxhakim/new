
import React from 'react';
import { cn } from '@/lib/utils';
import { ArrowDown, ArrowUp, MoreHorizontal } from 'lucide-react';

export interface TradeData {
  id: string;
  asset: string;
  date: string;
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  direction: 'Buy' | 'Sell';
  profitLoss: number;
  commission?: number;
  notes?: string;
}

interface TradeCardProps {
  trade: TradeData;
  className?: string;
  onClick?: () => void;
}

const TradeCard: React.FC<TradeCardProps> = ({ trade, className, onClick }) => {
  const isProfit = trade.profitLoss > 0;
  
  // Format the date
  const formattedDate = new Date(trade.date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
  
  // Format the profit/loss
  const formattedProfitLoss = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    signDisplay: 'always',
  }).format(trade.profitLoss);

  return (
    <div 
      className={cn(
        "bg-white rounded-xl p-4 shadow-card border border-neutral-200 transition-all duration-300 hover:shadow-md",
        "cursor-pointer",
        className
      )}
      onClick={onClick}
    >
      <div className="flex justify-between items-start">
        <div className="flex items-center">
          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-50 mr-3">
            <span className="font-semibold text-blue-500">{trade.asset.slice(0, 2).toUpperCase()}</span>
          </div>
          <div>
            <h3 className="font-medium text-neutral-800">{trade.asset}</h3>
            <p className="text-xs text-neutral-500">{formattedDate}</p>
          </div>
        </div>
        <div className="flex items-center">
          <span 
            className={cn(
              "text-sm font-medium",
              isProfit ? "text-success" : "text-error"
            )}
          >
            {formattedProfitLoss}
          </span>
          <button className="ml-2 text-neutral-400 hover:text-neutral-600 transition-colors">
            <MoreHorizontal size={16} />
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4 mt-4">
        <div>
          <p className="text-xs text-neutral-500 mb-1">Direction</p>
          <div className={cn(
            "inline-flex items-center px-2 py-1 rounded-md text-xs font-medium",
            trade.direction === 'Buy' 
              ? "bg-success/10 text-success" 
              : "bg-error/10 text-error"
          )}>
            {trade.direction === 'Buy' ? <ArrowUp size={12} className="mr-1" /> : <ArrowDown size={12} className="mr-1" />}
            {trade.direction}
          </div>
        </div>
        <div>
          <p className="text-xs text-neutral-500 mb-1">Entry Price</p>
          <p className="text-sm font-medium">${trade.entryPrice.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-xs text-neutral-500 mb-1">Exit Price</p>
          <p className="text-sm font-medium">${trade.exitPrice.toFixed(2)}</p>
        </div>
      </div>
      
      {trade.notes && (
        <div className="mt-3 pt-3 border-t border-neutral-100">
          <p className="text-xs text-neutral-500 mb-1">Notes</p>
          <p className="text-xs text-neutral-600 line-clamp-2">{trade.notes}</p>
        </div>
      )}
    </div>
  );
};

export default TradeCard;
