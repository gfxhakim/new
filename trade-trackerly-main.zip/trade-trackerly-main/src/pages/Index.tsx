
import React from 'react';
import Navbar from '@/components/ui/navbar';
import WelcomeSection from '@/components/home/welcome-section';
import MetricsSection from '@/components/home/metrics-section';
import RecentTrades from '@/components/home/recent-trades';

const Index: React.FC = () => {
  return (
    <div className="min-h-screen bg-neutral-200">
      <Navbar />
      <main>
        <WelcomeSection />
        <MetricsSection />
        <RecentTrades />
      </main>
    </div>
  );
};

export default Index;
