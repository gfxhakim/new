
import React, { useState } from 'react';
import Navbar from '@/components/ui/navbar';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import {
  CalendarIcon,
  ChevronDown,
  BarChart,
  LineChart,
  PieChart,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Percent,
  CandlestickChart
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart as RechartsBarChart,
  Bar,
  Line,
  ComposedChart,
  Legend,
  PieChart as RechartsPieChart,
  Pie,
  Cell
} from 'recharts';

// Mock data
const equityCurveData = [
  { date: 'Jan', equity: 10000 },
  { date: 'Feb', equity: 11200 },
  { date: 'Mar', equity: 10800 },
  { date: 'Apr', equity: 12500 },
  { date: 'May', equity: 13200 },
  { date: 'Jun', equity: 15000 },
  { date: 'Jul', equity: 14200 },
  { date: 'Aug', equity: 16500 },
  { date: 'Sep', equity: 18000 },
];

const profitLossData = [
  { date: 'Jan', profit: 1200, loss: -0 },
  { date: 'Feb', profit: 800, loss: -1200 },
  { date: 'Mar', profit: 2500, loss: -800 },
  { date: 'Apr', profit: 1500, loss: -800 },
  { date: 'May', profit: 3000, loss: -1200 },
  { date: 'Jun', profit: 1200, loss: -2000 },
  { date: 'Jul', profit: 3500, loss: -1200 },
  { date: 'Aug', profit: 2500, loss: -1000 },
  { date: 'Sep', profit: 2000, loss: -500 },
];

const performanceByAssetData = [
  { name: 'Apple', value: 35 },
  { name: 'Bitcoin', value: 25 },
  { name: 'Tesla', value: 15 },
  { name: 'Amazon', value: 10 },
  { name: 'Others', value: 15 },
];

const COLORS = ['#0A84FF', '#34C759', '#FF9500', '#FF3B30', '#5856D6'];

const dateRangeOptions = [
  { label: 'All Time', value: 'all' },
  { label: 'This Year', value: 'thisYear' },
  { label: 'Last 6 Months', value: '6months' },
  { label: 'Last 3 Months', value: '3months' },
  { label: 'This Month', value: 'thisMonth' },
  { label: 'Custom', value: 'custom' },
];

const assetOptions = [
  { label: 'All Assets', value: 'all' },
  { label: 'Stocks', value: 'stocks' },
  { label: 'Crypto', value: 'crypto' },
  { label: 'Forex', value: 'forex' },
  { label: 'Commodities', value: 'commodities' },
];

const strategyOptions = [
  { label: 'All Strategies', value: 'all' },
  { label: 'Day Trading', value: 'dayTrading' },
  { label: 'Swing Trading', value: 'swingTrading' },
  { label: 'Position Trading', value: 'positionTrading' },
  { label: 'Scalping', value: 'scalping' },
];

const Analysis: React.FC = () => {
  const [dateRange, setDateRange] = useState('all');
  const [customDateRange, setCustomDateRange] = useState<Date[]>([]);
  const [isCustomDateOpen, setIsCustomDateOpen] = useState(false);
  const [assetFilter, setAssetFilter] = useState('all');
  const [strategyFilter, setStrategyFilter] = useState('all');

  const formatNumberWithSign = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      signDisplay: 'always',
    }).format(value);
  };

  return (
    <div className="min-h-screen bg-neutral-200">
      <Navbar />

      <main className="container max-w-6xl mx-auto px-6 pt-32 pb-20">
        <h1 className="text-3xl font-bold text-neutral-800 mb-8">Performance Analysis</h1>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-card p-4 mb-8 animate-fade-in">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Date Range */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full md:w-auto justify-between">
                  <div className="flex items-center">
                    <CalendarIcon className="mr-2 h-4 w-4 text-neutral-500" />
                    <span className="text-sm">
                      {dateRange === 'custom'
                        ? customDateRange.length === 2
                          ? `${format(customDateRange[0], "MMM d")} - ${format(customDateRange[1], "MMM d")}`
                          : 'Custom'
                        : dateRangeOptions.find(o => o.value === dateRange)?.label || 'Date Range'}
                    </span>
                  </div>
                  <ChevronDown className="h-4 w-4 text-neutral-500 ml-2" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <div className="p-2">
                  <div className="space-y-1">
                    {dateRangeOptions.map((option) => (
                      <Button
                        key={option.value}
                        variant="ghost"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          dateRange === option.value && "bg-blue-50 text-blue-500"
                        )}
                        onClick={() => {
                          setDateRange(option.value);
                          if (option.value === 'custom') {
                            setIsCustomDateOpen(true);
                          }
                        }}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>

                  {dateRange === 'custom' && (
                    <Popover open={isCustomDateOpen} onOpenChange={setIsCustomDateOpen}>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal mt-2",
                            !customDateRange.length && "text-muted-foreground"
                          )}
                        >
                          {customDateRange.length === 0
                            ? "Select dates"
                            : customDateRange.length === 1
                            ? format(customDateRange[0], "MMM d, yyyy")
                            : `${format(customDateRange[0], "MMM d, yyyy")} - ${format(
                                customDateRange[1],
                                "MMM d, yyyy"
                              )}`}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="range"
                          selected={
                            customDateRange.length === 2
                              ? { from: customDateRange[0], to: customDateRange[1] }
                              : customDateRange.length === 1
                              ? { from: customDateRange[0], to: customDateRange[0] }
                              : undefined
                          }
                          onSelect={(range) => {
                            if (range?.from) {
                              if (range.to) {
                                setCustomDateRange([range.from, range.to]);
                                setIsCustomDateOpen(false);
                              } else {
                                setCustomDateRange([range.from]);
                              }
                            }
                          }}
                          className="p-3 pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  )}
                </div>
              </PopoverContent>
            </Popover>

            {/* Asset Filter */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full md:w-auto justify-between">
                  <div className="flex items-center">
                    <CandlestickChart className="mr-2 h-4 w-4 text-neutral-500" />
                    <span className="text-sm">
                      {assetOptions.find(o => o.value === assetFilter)?.label || 'Asset'}
                    </span>
                  </div>
                  <ChevronDown className="h-4 w-4 text-neutral-500 ml-2" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <div className="p-2 space-y-1">
                  {assetOptions.map((option) => (
                    <Button
                      key={option.value}
                      variant="ghost"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        assetFilter === option.value && "bg-blue-50 text-blue-500"
                      )}
                      onClick={() => setAssetFilter(option.value)}
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>

            {/* Strategy Filter */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full md:w-auto justify-between">
                  <div className="flex items-center">
                    <LineChart className="mr-2 h-4 w-4 text-neutral-500" />
                    <span className="text-sm">
                      {strategyOptions.find(o => o.value === strategyFilter)?.label || 'Strategy'}
                    </span>
                  </div>
                  <ChevronDown className="h-4 w-4 text-neutral-500 ml-2" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <div className="p-2 space-y-1">
                  {strategyOptions.map((option) => (
                    <Button
                      key={option.value}
                      variant="ghost"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        strategyFilter === option.value && "bg-blue-50 text-blue-500"
                      )}
                      onClick={() => setStrategyFilter(option.value)}
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {/* Summary KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow-card p-4 animate-scale-in">
            <div className="flex items-center mb-2">
              <DollarSign className="text-blue-500 mr-2 h-5 w-5" />
              <h3 className="text-sm font-medium text-neutral-600">Total P&L</h3>
            </div>
            <p className="text-2xl font-bold text-neutral-800">+$8,000</p>
          </div>

          <div className="bg-white rounded-xl shadow-card p-4 animate-scale-in [animation-delay:100ms]">
            <div className="flex items-center mb-2">
              <Percent className="text-success mr-2 h-5 w-5" />
              <h3 className="text-sm font-medium text-neutral-600">Win Rate</h3>
            </div>
            <p className="text-2xl font-bold text-neutral-800">68%</p>
          </div>

          <div className="bg-white rounded-xl shadow-card p-4 animate-scale-in [animation-delay:200ms]">
            <div className="flex items-center mb-2">
              <TrendingUp className="text-success mr-2 h-5 w-5" />
              <h3 className="text-sm font-medium text-neutral-600">Avg. Win</h3>
            </div>
            <p className="text-2xl font-bold text-neutral-800">$450.75</p>
          </div>

          <div className="bg-white rounded-xl shadow-card p-4 animate-scale-in [animation-delay:300ms]">
            <div className="flex items-center mb-2">
              <TrendingDown className="text-error mr-2 h-5 w-5" />
              <h3 className="text-sm font-medium text-neutral-600">Avg. Loss</h3>
            </div>
            <p className="text-2xl font-bold text-neutral-800">$215.30</p>
          </div>
        </div>

        {/* Charts & Analysis */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          {/* Equity Curve */}
          <div className="bg-white rounded-xl shadow-card p-6 animate-fade-in [animation-delay:100ms]">
            <h3 className="text-lg font-semibold text-neutral-800 mb-4 flex items-center">
              <LineChart className="text-blue-500 mr-2 h-5 w-5" />
              Equity Curve
            </h3>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={equityCurveData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorEquity" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0A84FF" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#0A84FF" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="date" stroke="#86868B" />
                  <YAxis
                    stroke="#86868B"
                    tickFormatter={(value) => `$${value.toLocaleString()}`}
                  />
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E5EA" />
                  <Tooltip
                    formatter={(value) => [`$${value.toLocaleString()}`, 'Equity']}
                    labelFormatter={(label) => `Date: ${label}`}
                  />
                  <Area
                    type="monotone"
                    dataKey="equity"
                    stroke="#0A84FF"
                    strokeWidth={2}
                    fill="url(#colorEquity)"
                    activeDot={{ r: 6 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Profit/Loss Chart */}
          <div className="bg-white rounded-xl shadow-card p-6 animate-fade-in [animation-delay:200ms]">
            <h3 className="text-lg font-semibold text-neutral-800 mb-4 flex items-center">
              <BarChart className="text-blue-500 mr-2 h-5 w-5" />
              Monthly Profit/Loss
            </h3>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={profitLossData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <XAxis dataKey="date" stroke="#86868B" />
                  <YAxis
                    stroke="#86868B"
                    tickFormatter={(value) => `$${Math.abs(value).toLocaleString()}`}
                  />
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E5EA" />
                  <Tooltip
                    formatter={(value) => [formatNumberWithSign(Number(value)), Number(value) >= 0 ? 'Profit' : 'Loss']}
                    labelFormatter={(label) => `Month: ${label}`}
                  />
                  <Legend />
                  <Bar dataKey="profit" name="Profit" fill="#34C759" radius={[5, 5, 0, 0]} />
                  <Bar dataKey="loss" name="Loss" fill="#FF3B30" radius={[5, 5, 0, 0]} />
                  <Line
                    type="monotone"
                    dataKey="profit"
                    name="Trend"
                    stroke="#0A84FF"
                    strokeWidth={2}
                    dot={false}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Win Rate Gauge */}
          <div className="bg-white rounded-xl shadow-card p-6 animate-fade-in [animation-delay:300ms]">
            <h3 className="text-lg font-semibold text-neutral-800 mb-4 flex items-center">
              <Percent className="text-blue-500 mr-2 h-5 w-5" />
              Win Rate
            </h3>
            <div className="flex flex-col items-center">
              <div className="relative h-40 w-40">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-3xl font-bold text-neutral-800">68%</div>
                </div>
                <div className="h-full w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={[
                          { name: 'Win', value: 68 },
                          { name: 'Loss', value: 32 },
                        ]}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        startAngle={180}
                        endAngle={-180}
                        dataKey="value"
                      >
                        <Cell key="cell-0" fill="#34C759" />
                        <Cell key="cell-1" fill="#E5E5EA" />
                      </Pie>
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="flex justify-between w-full mt-4">
                <div className="text-center">
                  <div className="text-sm text-neutral-500">Win Count</div>
                  <div className="text-lg font-semibold text-neutral-800">84</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-neutral-500">Loss Count</div>
                  <div className="text-lg font-semibold text-neutral-800">40</div>
                </div>
              </div>
            </div>
          </div>

          {/* Risk/Reward */}
          <div className="bg-white rounded-xl shadow-card p-6 animate-fade-in [animation-delay:400ms]">
            <h3 className="text-lg font-semibold text-neutral-800 mb-4 flex items-center">
              <TrendingUp className="text-blue-500 mr-2 h-5 w-5" />
              Risk/Reward
            </h3>
            <div className="flex flex-col h-[calc(100%-2rem)] justify-between">
              <div className="flex justify-center">
                <div className="bg-blue-50 rounded-full px-6 py-3 text-center">
                  <div className="text-sm text-blue-500">Ratio</div>
                  <div className="text-3xl font-bold text-neutral-800">1:2.1</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="bg-error/10 p-4 rounded-lg text-center">
                  <div className="text-sm text-error">Avg. Risk</div>
                  <div className="text-xl font-semibold text-neutral-800">$215.30</div>
                </div>
                <div className="bg-success/10 p-4 rounded-lg text-center">
                  <div className="text-sm text-success">Avg. Reward</div>
                  <div className="text-xl font-semibold text-neutral-800">$450.75</div>
                </div>
              </div>
            </div>
          </div>

          {/* Performance by Asset */}
          <div className="bg-white rounded-xl shadow-card p-6 animate-fade-in [animation-delay:500ms]">
            <h3 className="text-lg font-semibold text-neutral-800 mb-4 flex items-center">
              <PieChart className="text-blue-500 mr-2 h-5 w-5" />
              Performance by Asset
            </h3>
            <div className="h-[calc(100%-2rem)]">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={performanceByAssetData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({
                      cx,
                      cy,
                      midAngle,
                      innerRadius,
                      outerRadius,
                      percent,
                      name,
                    }) => {
                      const radius = innerRadius + (outerRadius - innerRadius) * 1.3;
                      const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
                      const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));

                      return (
                        <text
                          x={x}
                          y={y}
                          fill="#86868B"
                          textAnchor={x > cx ? 'start' : 'end'}
                          dominantBaseline="central"
                          fontSize="12"
                        >
                          {name} ({(percent * 100).toFixed(0)}%)
                        </text>
                      );
                    }}
                  >
                    {performanceByAssetData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Additional Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-fade-in [animation-delay:600ms]">
          <div className="bg-white rounded-xl shadow-card p-6">
            <h3 className="text-sm font-medium text-neutral-600 mb-2">Maximum Drawdown</h3>
            <p className="text-2xl font-bold text-error">-$1,850.00</p>
            <p className="text-sm text-neutral-500 mt-1">-9.25% from peak</p>
          </div>

          <div className="bg-white rounded-xl shadow-card p-6">
            <h3 className="text-sm font-medium text-neutral-600 mb-2">Expected Value</h3>
            <p className="text-2xl font-bold text-success">+$168.42</p>
            <p className="text-sm text-neutral-500 mt-1">Per trade average</p>
          </div>

          <div className="bg-white rounded-xl shadow-card p-6">
            <h3 className="text-sm font-medium text-neutral-600 mb-2">Best Trade</h3>
            <p className="text-2xl font-bold text-success">+$1,250.00</p>
            <p className="text-sm text-neutral-500 mt-1">BTC on Sep 10</p>
          </div>

          <div className="bg-white rounded-xl shadow-card p-6">
            <h3 className="text-sm font-medium text-neutral-600 mb-2">Worst Trade</h3>
            <p className="text-2xl font-bold text-error">-$750.00</p>
            <p className="text-sm text-neutral-500 mt-1">TSLA on Aug 12</p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Analysis;
