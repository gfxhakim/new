
import React, { useState } from 'react';
import Navbar from '@/components/ui/navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Camera, LogOut, Copy, Check } from 'lucide-react';
import { toast } from 'sonner';

const Profile: React.FC = () => {
  const [username, setUsername] = useState('JohnTrader');
  const [email, setEmail] = useState('john.trader@example.com');
  const [balance, setBalance] = useState('25,000.00');
  const [experience, setExperience] = useState('Intermediate');
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [mobileNotifications, setMobileNotifications] = useState(false);
  const [apiKey, setApiKey] = useState('sk_live_xxxxxxxxxxxxxxxxxxxxxxxx');
  const [copied, setCopied] = useState(false);

  const handleCopyApiKey = () => {
    navigator.clipboard.writeText(apiKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success('API key copied to clipboard');
  };

  const handleLogout = () => {
    toast.info('Logged out successfully');
    // Logout logic would go here
  };

  return (
    <div className="min-h-screen bg-neutral-200">
      <Navbar />
      
      <main className="container max-w-4xl mx-auto px-6 pt-32 pb-20">
        <h1 className="text-3xl font-bold text-neutral-800 mb-8">Your Profile</h1>
        
        <div className="bg-white rounded-xl shadow-card p-8 mb-8 animate-fade-in">
          <div className="flex flex-col md:flex-row gap-8 items-start">
            {/* Profile Picture */}
            <div className="relative">
              <div className="w-24 h-24 md:w-32 md:h-32 bg-blue-100 rounded-full flex items-center justify-center text-blue-500 font-bold text-2xl">
                JT
              </div>
              <button className="absolute bottom-0 right-0 bg-blue-500 text-white p-2 rounded-full shadow-md hover:bg-blue-600 transition-colors">
                <Camera size={16} />
              </button>
            </div>
            
            {/* User Info */}
            <div className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input 
                    id="username" 
                    value={username} 
                    onChange={(e) => setUsername(e.target.value)} 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="balance">Account Balance</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500">$</span>
                    <Input 
                      id="balance" 
                      value={balance} 
                      onChange={(e) => setBalance(e.target.value)} 
                      className="pl-7"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="experience">Trading Experience</Label>
                  <select
                    id="experience"
                    value={experience}
                    onChange={(e) => setExperience(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                    <option value="Professional">Professional</option>
                  </select>
                </div>
              </div>
              
              <div className="pt-2">
                <Button type="button" className="mr-4">
                  Save Changes
                </Button>
                <Button variant="outline" type="button">
                  Change Password
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Settings Section */}
        <div className="bg-white rounded-xl shadow-card p-8 mb-8 animate-fade-in [animation-delay:100ms]">
          <h2 className="text-xl font-semibold text-neutral-800 mb-6">Settings</h2>
          
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-md font-medium text-neutral-800">Email Notifications</h3>
                <p className="text-sm text-neutral-500">Receive email notifications for trades and alerts</p>
              </div>
              <Switch 
                checked={emailNotifications} 
                onCheckedChange={setEmailNotifications} 
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-md font-medium text-neutral-800">Mobile Notifications</h3>
                <p className="text-sm text-neutral-500">Receive mobile push notifications</p>
              </div>
              <Switch 
                checked={mobileNotifications} 
                onCheckedChange={setMobileNotifications} 
              />
            </div>
            
            <div className="py-4 border-t border-neutral-100">
              <h3 className="text-md font-medium text-neutral-800 mb-2">API Key Management</h3>
              <div className="relative">
                <Input 
                  type="password" 
                  value={apiKey} 
                  readOnly 
                  className="pr-12"
                />
                <button 
                  onClick={handleCopyApiKey}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-blue-500 transition-colors"
                >
                  {copied ? <Check size={18} /> : <Copy size={18} />}
                </button>
              </div>
              <p className="text-xs text-neutral-500 mt-2">
                Use this API key to connect external trading platforms to your journal
              </p>
            </div>
          </div>
        </div>
        
        {/* Logout Button */}
        <div className="flex justify-center animate-fade-in [animation-delay:200ms]">
          <Button 
            variant="outline" 
            className="text-error hover:bg-error/10 border-error/30"
            onClick={handleLogout}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </main>
    </div>
  );
};

export default Profile;
