
import React, { useState } from 'react';
import Navbar from '@/components/ui/navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { 
  Search, 
  Calendar as CalendarIcon, 
  ChevronDown, 
  Plus, 
  Upload, 
  ArrowUpDown,
  ArrowDown,
  ArrowUp,
  ArrowRight
} from 'lucide-react';
import TradeCard, { TradeData } from '@/components/ui/trade-card';
import AddTradeModal from '@/components/ui/add-trade-modal';
import { toast } from 'sonner';

// Mock data - would be replaced with real data in a production app
const initialTradesData: TradeData[] = [
  {
    id: '1',
    asset: 'Apple Inc.',
    date: '2023-09-15T10:30:00',
    entryPrice: 170.50,
    exitPrice: 175.25,
    quantity: 10,
    direction: 'Buy',
    profitLoss: 47.50,
    notes: 'Entered after positive earnings report, exited at resistance level.',
  },
  {
    id: '2',
    asset: 'Bitcoin',
    date: '2023-09-10T14:45:00',
    entryPrice: 26800.00,
    exitPrice: 27500.00,
    quantity: 0.5,
    direction: 'Buy',
    profitLoss: 350.00,
  },
  {
    id: '3',
    asset: 'Tesla Inc.',
    date: '2023-09-05T09:15:00',
    entryPrice: 245.75,
    exitPrice: 238.50,
    quantity: 8,
    direction: 'Sell',
    profitLoss: -58.00,
    commission: 9.99,
    notes: 'Shorted at resistance, covered too early.',
  },
  {
    id: '4',
    asset: 'EUR/USD',
    date: '2023-09-01T11:20:00',
    entryPrice: 1.0825,
    exitPrice: 1.0875,
    quantity: 10000,
    direction: 'Buy',
    profitLoss: 500.00,
  },
  {
    id: '5',
    asset: 'Amazon.com Inc.',
    date: '2023-08-28T15:30:00',
    entryPrice: 138.50,
    exitPrice: 135.75,
    quantity: 12,
    direction: 'Buy',
    profitLoss: -33.00,
    notes: 'Entered too early, market reversed after Fed announcement.',
  },
  {
    id: '6',
    asset: 'Gold',
    date: '2023-08-25T13:45:00',
    entryPrice: 1950.75,
    exitPrice: 1975.50,
    quantity: 1,
    direction: 'Buy',
    profitLoss: 24.75,
  },
  {
    id: '7',
    asset: 'Microsoft Corp.',
    date: '2023-08-20T10:15:00',
    entryPrice: 325.20,
    exitPrice: 330.50,
    quantity: 5,
    direction: 'Buy',
    profitLoss: 26.50,
  },
  {
    id: '8',
    asset: 'S&P 500 Index',
    date: '2023-08-15T09:30:00',
    entryPrice: 4450.25,
    exitPrice: 4425.75,
    quantity: 1,
    direction: 'Sell',
    profitLoss: 24.50,
    notes: 'Technical short at resistance level, closed at support.',
  }
];

const dateRangeOptions = [
  { label: 'All Time', value: 'all' },
  { label: 'Today', value: 'today' },
  { label: 'Last 7 Days', value: '7days' },
  { label: 'Last 30 Days', value: '30days' },
  { label: 'This Month', value: 'thisMonth' },
  { label: 'Last Month', value: 'lastMonth' },
  { label: 'Custom', value: 'custom' },
];

const Trades: React.FC = () => {
  const [trades, setTrades] = useState<TradeData[]>(initialTradesData);
  const [searchQuery, setSearchQuery] = useState('');
  const [dateRange, setDateRange] = useState('all');
  const [customDateRange, setCustomDateRange] = useState<Date[]>([]);
  const [isCustomDateOpen, setIsCustomDateOpen] = useState(false);
  const [directionFilter, setDirectionFilter] = useState<'all' | 'buy' | 'sell'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  
  // Filtering logic
  const filteredTrades = trades.filter(trade => {
    // Search filter
    if (searchQuery && !trade.asset.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Direction filter
    if (directionFilter !== 'all') {
      if (directionFilter === 'buy' && trade.direction !== 'Buy') return false;
      if (directionFilter === 'sell' && trade.direction !== 'Sell') return false;
    }
    
    // Date filter
    const tradeDate = new Date(trade.date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    switch (dateRange) {
      case 'today':
        return tradeDate >= today;
      case '7days':
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        sevenDaysAgo.setHours(0, 0, 0, 0);
        return tradeDate >= sevenDaysAgo;
      case '30days':
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        thirtyDaysAgo.setHours(0, 0, 0, 0);
        return tradeDate >= thirtyDaysAgo;
      case 'thisMonth':
        const firstDayThisMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        return tradeDate >= firstDayThisMonth;
      case 'lastMonth':
        const firstDayLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const firstDayThisMonthForLastMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        return tradeDate >= firstDayLastMonth && tradeDate < firstDayThisMonthForLastMonth;
      case 'custom':
        if (customDateRange.length === 2) {
          const [startDate, endDate] = customDateRange;
          // Set endDate to end of day
          const endDateWithTime = new Date(endDate);
          endDateWithTime.setHours(23, 59, 59, 999);
          return tradeDate >= startDate && tradeDate <= endDateWithTime;
        }
        return true;
      default:
        return true;
    }
  });
  
  const handleAddTrade = (newTrade: Omit<TradeData, 'id'>) => {
    const tradeWithId: TradeData = {
      ...newTrade,
      id: Math.random().toString(36).substr(2, 9),
    };
    setTrades([tradeWithId, ...trades]);
  };
  
  const handleCustomDateSelect = (date: Date | undefined) => {
    if (!date) return;
    
    if (customDateRange.length === 0 || customDateRange.length === 2) {
      setCustomDateRange([date]);
    } else {
      const [startDate] = customDateRange;
      // Ensure endDate is after startDate
      if (date < startDate) {
        setCustomDateRange([date, startDate]);
      } else {
        setCustomDateRange([startDate, date]);
        setIsCustomDateOpen(false);
      }
    }
  };
  
  const formatDateRange = () => {
    if (customDateRange.length === 0) return 'Select dates';
    if (customDateRange.length === 1) return format(customDateRange[0], 'MMM d, yyyy');
    return `${format(customDateRange[0], 'MMM d, yyyy')} - ${format(customDateRange[1], 'MMM d, yyyy')}`;
  };
  
  return (
    <div className="min-h-screen bg-neutral-200">
      <Navbar />
      
      <main className="container max-w-6xl mx-auto px-6 pt-32 pb-20">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <h1 className="text-3xl font-bold text-neutral-800">Your Trades</h1>
          
          <div className="flex flex-wrap gap-3">
            <Button 
              onClick={() => setIsAddModalOpen(true)}
              className="shadow-button"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Trade
            </Button>
            <Button variant="outline" className="shadow-button">
              <Upload className="mr-2 h-4 w-4" />
              Import Trades
            </Button>
          </div>
        </div>
        
        {/* Filters */}
        <div className="bg-white rounded-xl shadow-card p-4 mb-8 animate-fade-in">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by asset..."
                className="pl-9"
              />
            </div>
            
            {/* Date Range */}
            <div className="w-full md:w-48">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-between">
                    <div className="flex items-center">
                      <CalendarIcon className="mr-2 h-4 w-4 text-neutral-500" />
                      <span className="text-sm truncate">
                        {dateRange === 'custom' 
                          ? formatDateRange() 
                          : dateRangeOptions.find(o => o.value === dateRange)?.label || 'Date Range'}
                      </span>
                    </div>
                    <ChevronDown className="h-4 w-4 text-neutral-500" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <div className="p-2">
                    <div className="space-y-1">
                      {dateRangeOptions.map((option) => (
                        <Button
                          key={option.value}
                          variant="ghost"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            dateRange === option.value && "bg-blue-50 text-blue-500"
                          )}
                          onClick={() => {
                            setDateRange(option.value);
                            if (option.value === 'custom') {
                              setIsCustomDateOpen(true);
                              if (customDateRange.length === 0) {
                                setCustomDateRange([new Date()]);
                              }
                            }
                          }}
                        >
                          {option.label}
                        </Button>
                      ))}
                    </div>
                    
                    {dateRange === 'custom' && (
                      <Popover open={isCustomDateOpen} onOpenChange={setIsCustomDateOpen}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal mt-2",
                              !customDateRange.length && "text-muted-foreground"
                            )}
                          >
                            {customDateRange.length === 0
                              ? "Select dates"
                              : customDateRange.length === 1
                              ? format(customDateRange[0], "MMM d, yyyy")
                              : `${format(customDateRange[0], "MMM d, yyyy")} - ${format(
                                  customDateRange[1],
                                  "MMM d, yyyy"
                                )}`}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="range"
                            selected={
                              customDateRange.length === 2
                                ? { from: customDateRange[0], to: customDateRange[1] }
                                : customDateRange.length === 1
                                ? { from: customDateRange[0], to: customDateRange[0] }
                                : undefined
                            }
                            onSelect={(range) => {
                              if (range?.from) {
                                if (range.to) {
                                  setCustomDateRange([range.from, range.to]);
                                  setIsCustomDateOpen(false);
                                } else {
                                  setCustomDateRange([range.from]);
                                }
                              }
                            }}
                            className="p-3 pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    )}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
            
            {/* Direction Filter */}
            <div className="flex">
              <Button
                variant={directionFilter === 'all' ? 'default' : 'outline'}
                className="rounded-r-none border-r-0"
                onClick={() => setDirectionFilter('all')}
              >
                <ArrowUpDown className="mr-2 h-4 w-4" />
                All
              </Button>
              <Button
                variant={directionFilter === 'buy' ? 'default' : 'outline'}
                className="rounded-none border-r-0"
                onClick={() => setDirectionFilter('buy')}
              >
                <ArrowUp className="mr-2 h-4 w-4 text-success" />
                Buy
              </Button>
              <Button
                variant={directionFilter === 'sell' ? 'default' : 'outline'}
                className="rounded-l-none"
                onClick={() => setDirectionFilter('sell')}
              >
                <ArrowDown className="mr-2 h-4 w-4 text-error" />
                Sell
              </Button>
            </div>
          </div>
        </div>
        
        {/* Trades Grid */}
        {filteredTrades.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
            {filteredTrades.map((trade, index) => (
              <TradeCard 
                key={trade.id} 
                trade={trade} 
                className={`animate-slide-in [animation-delay:${index * 50}ms]`}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-card p-8 text-center animate-fade-in">
            <h3 className="text-lg font-medium text-neutral-800 mb-2">No trades found</h3>
            <p className="text-neutral-500 mb-4">
              {searchQuery || dateRange !== 'all' || directionFilter !== 'all' 
                ? "Try adjusting your filters or search query." 
                : "Start by adding your first trade."}
            </p>
            {(searchQuery || dateRange !== 'all' || directionFilter !== 'all') && (
              <Button 
                variant="outline"
                onClick={() => {
                  setSearchQuery('');
                  setDateRange('all');
                  setDirectionFilter('all');
                  setCustomDateRange([]);
                }}
              >
                Clear Filters
              </Button>
            )}
          </div>
        )}
        
        {/* Pagination */}
        {filteredTrades.length > 0 && (
          <div className="flex justify-center mt-8 animate-fade-in">
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="outline" size="sm" className="bg-blue-50 text-blue-500">
                1
              </Button>
              <Button variant="outline" size="sm">
                2
              </Button>
              <Button variant="outline" size="sm">
                3
              </Button>
              <span className="text-neutral-400">...</span>
              <Button variant="outline" size="sm">
                Next
              </Button>
            </div>
          </div>
        )}
        
        {/* Add Trade Modal */}
        <AddTradeModal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onAddTrade={handleAddTrade}
        />
      </main>
    </div>
  );
};

export default Trades;
